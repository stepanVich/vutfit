import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {
  MatButtonModule,
  MatCardModule,
  MatCheckboxModule,
  MatDatepickerModule,
  MatFormFieldModule,
  MatGridListModule,
  MatInputModule,
  MatNativeDateModule,
  MatProgressSpinnerModule,
} from '@angular/material';
import { FormsModule } from '@angular/forms';
import { MeetingService } from './meeting.service';
import { ProfessorInfoComponent } from './professor-info/professor-info.component';
import { ToastrModule } from 'ngx-toastr';
import { ProfessorComponent } from './professor/professor.component';
import { StudentComponent } from './student/student.component';
import { LoginComponent } from './login/login.component';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

const appRoutes: Routes = [{
  path: '',
  children: [
    {path: 'login', component: LoginComponent},
    {path: 'student', component: StudentComponent},
    {path: 'professor', component: ProfessorComponent},
    {path: '**', redirectTo: 'login'},
  ],
}];

@NgModule({
  declarations: [
    AppComponent,
    ProfessorInfoComponent,
    ProfessorComponent,
    StudentComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    MatButtonModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatNativeDateModule,
    MatInputModule,
    MatGridListModule,
    MatCardModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    ToastrModule.forRoot(),
    RouterModule.forRoot(appRoutes),
    HttpClientModule,
  ],
  providers: [
    MeetingService,
  ],
  entryComponents: [
    ProfessorInfoComponent,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
