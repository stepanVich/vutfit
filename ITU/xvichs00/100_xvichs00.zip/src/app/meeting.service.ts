import { Injectable } from '@angular/core';
import { MeetingModel, ProfessorModel, StudentModel } from './models';
import { Observable } from 'rxjs';

const PROFESSORS: ProfessorModel[] = [
  {
    id: 0,
    name: 'doc. Doe',
    room: 'A042'
  },
  {
    id: 1,
    name: 'Ing. Wrona',
    room: 'A310'
  },
  {
    id: 2,
    name: 'Ing. Hrubý',
    room: 'B540'
  },
  {
    id: 3,
    name: 'Ing. Šima',
    room: 'L303'
  },
  {
    id: 4,
    name: 'prof. Vojnar',
    room: 'C550'
  },
  {
    id: 5,
    name: 'prof. Strnadel',
    room: 'L305'
  }
];

const STUDENTS: StudentModel[] = [
  {
    login: 'xpakes00'
  },
  {
    login: 'xvichs00'
  },
  {
    login: 'xresov00'
  },
  {
    login: 'xpilat05'
  },
  {
    login: 'xuchyt02'
  }
];

const MEETINGS: MeetingModel[] = [
  {
    date: '2017-12-05',
    hour: 10,
    profId: 0
  },
  {
    date: '2017-12-05',
    hour: 12,
    profId: 1,
    studLogin: 'xuchyt02'
  },
  {
    date: '2017-12-05',
    hour: 10,
    profId: 1
  },
  {
    date: '2017-12-06',
    hour: 11,
    profId: 1,
    studLogin: 'xpilat05'
  },
  {
    date: '2017-12-05',
    hour: 11,
    profId: 5,
    studLogin: 'xpakes00'
  },
  {
    date: '2017-12-05',
    hour: 16,
    profId: 3,
    studLogin: 'xpakes00'
  },
  {
    date: '2017-12-05',
    hour: 10,
    profId: 3
  },
  {
    date: '2017-12-05',
    hour: 11,
    profId: 3
  },
  {
    date: '2017-12-05',
    hour: 12,
    profId: 3
  },
  {
    date: '2017-12-05',
    hour: 17,
    profId: 3
  },
  {
    date: '2017-12-05',
    hour: 9,
    profId: 4,
    studLogin: 'xresov00'
  },
  {
    date: '2017-12-05',
    hour: 10,
    profId: 4,
    studLogin: 'xvichs00'
  }
];

@Injectable()
export class MeetingService {
  private meetings = MEETINGS;

  getTableForDate(date: string, startHour: number, endHour: number): Observable<{[profId: string]: MeetingModel[]}> {
    const table = PROFESSORS
      .map(professor => professor.id)
      .reduce((acc, profId) => ({
          ...acc,
          [profId]: new Array(endHour - startHour)
            .fill(null)
            .map((_, index) => startHour + index)
            .map(hour => this.meetings.find(meeting => meeting.profId === profId && meeting.date === date && meeting.hour === hour))
        }), {});
    return Observable.of(table).delay(1000);
  }

  getProfessors(): Observable<ProfessorModel[]> {
    return Observable.of(PROFESSORS);
  }

  getMeetingsByProfId(id: number): Observable<MeetingModel[]> {
    const meetings = this.meetings
      .filter(m => m.profId === id);
    console.log(meetings);
    return Observable.of(meetings);
  }

  setMeeting(meeting: MeetingModel): void {
    console.log(meeting);
    this.meetings = [
      ...this.meetings.filter(m => meeting.date !== m.date || meeting.hour !== m.hour || meeting.profId !== m.profId),
      meeting
    ];
  }

  addMeeting(meeting: MeetingModel): void {
    console.log('addMeeting(): ' + meeting + ' ' + this.meetings);
    this.meetings.push(meeting);
  }

  isMeeting(meeting: MeetingModel): boolean {
    if (!meeting) {
      return false;
    }

    return !!this.meetings.find(m => meeting.date === m.date && meeting.hour === m.hour && meeting.profId === m.profId);
  }

  deleteMeeting(meeting: MeetingModel): void {
    if (meeting) {
      this.meetings.filter(m => meeting.date !== m.date || meeting.hour !== m.hour || meeting.profId !== m.profId);
      console.log(meeting);
      console.log(this.meetings);
    }
  }
}
