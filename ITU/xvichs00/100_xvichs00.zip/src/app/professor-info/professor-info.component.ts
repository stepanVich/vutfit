import {Component, Inject} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ProfessorModel } from '../models';

@Component({
  selector: 'itu-professor-info',
  templateUrl: './professor-info.component.html',
  styleUrls: ['./professor-info.component.scss']
})
export class ProfessorInfoComponent {
  constructor(private dialogRef: MatDialogRef<ProfessorInfoComponent>, @Inject(MAT_DIALOG_DATA) public professor: ProfessorModel) { }

  closeDialog(): void {
    this.dialogRef.close();
  }
}
