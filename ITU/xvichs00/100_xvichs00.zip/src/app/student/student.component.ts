import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { MatCheckboxChange, MatDialog } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { MeetingService } from '../meeting.service';
import { MeetingModel, ProfessorModel } from '../models';
import { ProfessorInfoComponent } from '../professor-info/professor-info.component';

const ITS_A_MEE = 'xresov00';

@Component({
  selector: 'itu-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.scss']
})
export class StudentComponent {
  readonly startHour = 8;
  readonly endHour = 18;
  table: {[profId: string]: MeetingModel[]};
  professors$: Observable<ProfessorModel[]>;
  date: string;

  constructor(private meetingService: MeetingService,
              private dialog: MatDialog,
              private toastr: ToastrService) {
    this.professors$ = this.meetingService.getProfessors();
    this.setDate('2017-12-05');
  }

  setDate(date: string): void {
    this.date = date;
    this.table = null;
    this.meetingService.getTableForDate(date, this.startHour, this.endHour).subscribe(
      table => {
        this.table = table;
      }
    );
  }

  get displayedHours(): string[] {
    return new Array(this.endHour - this.startHour)
      .fill(null)
      .map((_, index) => this.startHour + index)
      .map(hour => `${hour}:00`);
  }

  get tableColumns(): number {
    return this.endHour - this.startHour + 1;
  }

  get selectedDate(): string {
    return this.date;
  }

  set selectedDate(date: string) {
    this.setDate(moment(date).format('YYYY-MM-DD'));
  }

  updateMeeting(event: MatCheckboxChange, meeting: MeetingModel): void {
    this.meetingService.setMeeting({...meeting, studLogin: event.checked ? ITS_A_MEE : null});
    this.toastr.success('Termín zmenený');
  }

  isThisMe(studLogin: string): boolean {
    return studLogin === ITS_A_MEE;
  }

  showProfessorInfo(professor: ProfessorModel) {
    this.dialog.open(ProfessorInfoComponent, {
      data: professor
    });
  }
}
