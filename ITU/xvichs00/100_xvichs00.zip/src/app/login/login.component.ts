import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

const TOKEN_NAME = 'firebase_token';

@Component({
  selector: 'itu-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  email: string;
  password: string;
  logOk = false;

  constructor(private router: Router,
              private http: HttpClient,
              private toastr: ToastrService) { }

  setToken(token: string): void {
    localStorage.setItem(TOKEN_NAME, token);
  }

  onLoginSubmit(): void {
    if (this.logOk) {
      const payload = {
        email: this.email,
        password: this.password
      };
      this.http.post<any>('/auth/login', payload).subscribe(
        (data: any) => {
          if (data.token) {
            this.setToken(data.token);
            this.router.navigateByUrl('student');
          }
        },
        (error) => {
          console.error('error', error);
        }
      );
    } else {
      this.router.navigateByUrl('student');
      this.toastr.success('Prihlásenie úspešné!');
    }
  }
}
