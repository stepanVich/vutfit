export interface MeetingModel {
  date: string;
  hour: number;
  profId: number;
  studLogin?: string;
}

export interface ProfessorModel {
  id: number;
  name: string;
  room: string;
}

export interface StudentModel {
  login: string;
}
