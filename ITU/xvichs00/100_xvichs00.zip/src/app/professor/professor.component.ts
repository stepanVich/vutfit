import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { MatCheckboxChange, MatDialog } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { MeetingService } from '../meeting.service';
import { MeetingModel, ProfessorModel } from '../models';
import { ProfessorInfoComponent } from '../professor-info/professor-info.component';

const ITS_A_MEE = 0;

@Component({
  selector: 'itu-professor',
  templateUrl: './professor.component.html',
  styleUrls: ['./professor.component.scss']
})
export class ProfessorComponent {
  readonly startHour = 8;
  readonly endHour = 18;
  table: {[profId: string]: MeetingModel[]};
  professors$: Observable<ProfessorModel[]>;
  date: string;
  meetings$: Observable<MeetingModel[]>;

  constructor(private meetingService: MeetingService,
              private toastr: ToastrService) {
    this.professors$ = this.meetingService.getProfessors();
    this.setDate('2017-12-05');
  }

  setDate(date: string): void {
    this.date = date;
    this.table = null;
    this.meetingService.getTableForDate(date, this.startHour, this.endHour).subscribe(
      table => {
        this.table = table;
      }
    );
    this.meetings$ = this.meetingService.getMeetingsByProfId(0);
  }

  get displayedHours(): string[] {
    return new Array(this.endHour - this.startHour)
      .fill(null)
      .map((_, index) => this.startHour + index)
      .map(hour => `${hour}:00`);
  }

  get tableColumns(): number {
    return this.endHour - this.startHour;
  }

  get selectedDate(): string {
    return this.date;
  }

  set selectedDate(date: string) {
    this.setDate(moment(date).format('YYYY-MM-DD'));
  }

  updateMeeting(event: MatCheckboxChange, meeting: MeetingModel, hour: number): void {
    if (event.checked) {
      this.meetingService.addMeeting({
        date: this.date,
        hour: hour,
        profId: 0
      });
      console.log(hour);
      this.toastr.success('Termín pridaný!');
    } else {
      console.log(meeting);
      this.meetingService.deleteMeeting({
        date: this.date,
        hour: hour,
        profId: 0
      });
      this.toastr.success('Termín zmazaný!');
    }
  }

  isMeeting(meeting: MeetingModel): boolean {
    return meeting ? this.meetingService.isMeeting(meeting) : false;
  }

  isThisMe(profId: number): boolean {
    return profId === ITS_A_MEE;
  }
}

