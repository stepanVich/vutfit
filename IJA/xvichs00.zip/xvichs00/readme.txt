Projekt do předmětu IJA. Na projektu pracovali dva členové Štěpán Vích a Marek Rohel. Projekt implementuje hru Solitaire Klondike. Žádná rozšíření nebyla implementována.
