<?php
	$title = "Úvod";
	$isInternPage = false;
?>
<?php include('includes/header.php'); ?>

<p>Vítejte v bankovním informačním systému. Pokud chcete vstopit do systému použijte své přihlašovací jméno a heslo. Pokud jste své heslo a přihlašovací jméno zapomněli, použijte stránku pro obnovení hesla.</p>
<p>
	<ul>
		<li>
			<a href="login.php">Přihlásit se</a>
		</li>
		<li>
			<a href="zapomenute.php">Zapomenuté heslo</a>
		</li>
	</ul>
</p>

<?php include('includes/footer.php'); ?>
